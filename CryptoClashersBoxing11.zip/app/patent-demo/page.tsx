"use client"

import { useState } from "react"
import PatentInfo from "@/components/patent-info"
import MarketTestRunner from "@/components/market-test-runner"
import { kerberosAuth } from "@/lib/auth/kerberos"

export default function PatentDemoPage() {
  const [authenticated, setAuthenticated] = useState(false)

  const handleAuthenticate = async () => {
    const success = await kerberosAuth.authenticate()
    setAuthenticated(success)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-500 to-orange-500 mb-4">
            Market Melee™ Patent Demo
          </h1>
          <p className="text-xl text-gray-300">Showcasing our patent-pending technology</p>
        </div>

        <div className="grid gap-6">
          <PatentInfo />

          <MarketTestRunner />

          <div className="text-center text-sm text-gray-500 mt-4">
            <p>PATENT PENDING: US2025/STYRD - All Rights Reserved</p>
            <p>© {new Date().getFullYear()} StoneYard.Gaming</p>
          </div>
        </div>
      </div>
    </div>
  )
}

