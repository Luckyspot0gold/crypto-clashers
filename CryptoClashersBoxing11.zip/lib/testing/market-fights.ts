// PATENT PENDING: US2025/STYRD
// Market-driven match testing for Market Melee™ technology

import type { CandlestickData } from "@/lib/types"
import { marketMeleeFormula } from "@/lib/market-melee-formula"
import { coingecko } from "@/lib/api/coingecko"

/**
 * Market-driven match testing module
 * This implementation is protected under patent pending US2025/STYRD
 */
export class MarketFightTester {
  private leftFighter: string
  private rightFighter: string
  private rounds: number
  private useLiveData: boolean
  private logs: string[] = []

  constructor(options: { leftFighter: string; rightFighter: string; rounds?: number; useLiveData?: boolean }) {
    this.leftFighter = options.leftFighter
    this.rightFighter = options.rightFighter
    this.rounds = options.rounds || 8
    this.useLiveData = options.useLiveData || false
  }

  /**
   * Runs a market-driven match test
   * @returns Promise with test results
   */
  async runTest(): Promise<{
    winner: string | null
    leftScore: number
    rightScore: number
    logs: string[]
    knockOut: boolean
  }> {
    this.logs = []
    this.log(`Starting market fight test: ${this.leftFighter} vs ${this.rightFighter}`)
    this.log(`Rounds: ${this.rounds}, Using live data: ${this.useLiveData}`)

    let leftData: CandlestickData[] = []
    let rightData: CandlestickData[] = []

    try {
      // Fetch market data
      if (this.useLiveData && process.env.STYRD_EXCLUSIVE_KEY) {
        this.log("Fetching live market data...")
        leftData = await coingecko.fetchMarketData(this.leftFighter, 1)
        rightData = await coingecko.fetchMarketData(this.rightFighter, 1)
      } else {
        this.log("Using simulated market data")
        leftData = this.generateSimulatedData(this.leftFighter)
        rightData = this.generateSimulatedData(this.rightFighter)
      }

      // Run the match
      return this.simulateMatch(leftData, rightData)
    } catch (error) {
      this.log(`Error running market fight test: ${error}`)
      return {
        winner: null,
        leftScore: 0,
        rightScore: 0,
        logs: this.logs,
        knockOut: false,
      }
    }
  }

  /**
   * Simulates a match using the provided market data
   * @param leftData Left fighter's market data
   * @param rightData Right fighter's market data
   * @returns Match results
   */
  private simulateMatch(
    leftData: CandlestickData[],
    rightData: CandlestickData[],
  ): {
    winner: string | null
    leftScore: number
    rightScore: number
    logs: string[]
    knockOut: boolean
  } {
    let leftScore = 0
    let rightScore = 0
    let knockOut = false
    let winner: string | null = null

    // Simulate each round
    for (let round = 1; round <= this.rounds; round++) {
      // Get data for this round
      const leftCandle = leftData[Math.min(round - 1, leftData.length - 1)]
      const rightCandle = rightData[Math.min(round - 1, rightData.length - 1)]

      // Calculate performance
      const leftPerformance = marketMeleeFormula(leftCandle, leftData.slice(0, round - 1), this.leftFighter)
      const rightPerformance = marketMeleeFormula(rightCandle, rightData.slice(0, round - 1), this.rightFighter)

      // Calculate round points
      let leftRoundPoints = 0
      let rightRoundPoints = 0

      // Award points based on percent change
      const leftChange = leftPerformance.percentChange
      const rightChange = rightPerformance.percentChange

      if (leftChange > rightChange) {
        leftRoundPoints += 10
        this.log(`Round ${round}: ${this.leftFighter} wins with better price performance! +10 points`)
      } else if (rightChange > leftChange) {
        rightRoundPoints += 10
        this.log(`Round ${round}: ${this.rightFighter} wins with better price performance! +10 points`)
      } else {
        // Tie
        leftRoundPoints += 5
        rightRoundPoints += 5
        this.log(`Round ${round}: Tie on price performance! Both fighters get +5 points`)
      }

      // Award bonus points for volatility
      if (leftPerformance.volatility > rightPerformance.volatility) {
        leftRoundPoints += 2
        this.log(`${this.leftFighter} shows higher volatility! +2 bonus points`)
      } else if (rightPerformance.volatility > leftPerformance.volatility) {
        rightRoundPoints += 2
        this.log(`${this.rightFighter} shows higher volatility! +2 bonus points`)
      }

      // Award bonus points for volume
      if (leftPerformance.volume > rightPerformance.volume) {
        leftRoundPoints += 3
        this.log(`${this.leftFighter} has higher trading volume! +3 bonus points`)
      } else if (rightPerformance.volume > leftPerformance.volume) {
        rightRoundPoints += 3
        this.log(`${this.rightFighter} has higher trading volume! +3 bonus points`)
      }

      // Check for special moves
      if (leftPerformance.isFuryMode) {
        leftRoundPoints += 5
        this.log(`⚡⚡ ${this.leftFighter} ENTERS FURY MODE! +5 bonus points ⚡⚡`)
      }

      if (rightPerformance.isFuryMode) {
        rightRoundPoints += 5
        this.log(`⚡⚡ ${this.rightFighter} ENTERS FURY MODE! +5 bonus points ⚡⚡`)
      }

      // Simulate market-driven combos
      if (leftChange > 2.0) {
        const comboHits = Math.floor(leftChange * 10)
        this.log(
          `Round ${round}: ${this.leftFighter} +${leftChange.toFixed(1)}% → Player lands ${comboHits}-hit combo!`,
        )
        leftRoundPoints += comboHits
      }

      if (rightChange > 2.0) {
        const comboHits = Math.floor(rightChange * 10)
        this.log(
          `Round ${round}: ${this.rightFighter} +${rightChange.toFixed(1)}% → Player lands ${comboHits}-hit combo!`,
        )
        rightRoundPoints += comboHits
      }

      // Update total scores
      leftScore += leftRoundPoints
      rightScore += rightRoundPoints

      this.log(
        `Round ${round} Score: ${this.leftFighter} +${leftRoundPoints} | ${this.rightFighter} +${rightRoundPoints}`,
      )
      this.log(`Total Score: ${this.leftFighter} ${leftScore} | ${this.rightFighter} ${rightScore}`)

      // Check for knockout (if one fighter is ahead by 30+ points)
      if (leftScore >= rightScore + 30) {
        this.log(`💥 KNOCKOUT: ${this.leftFighter} wins by knockout in round ${round}!`)
        knockOut = true
        winner = this.leftFighter
        break
      } else if (rightScore >= leftScore + 30) {
        this.log(`💥 KNOCKOUT: ${this.rightFighter} wins by knockout in round ${round}!`)
        knockOut = true
        winner = this.rightFighter
        break
      }
    }

    // Determine winner if no knockout
    if (!knockOut) {
      if (leftScore > rightScore) {
        winner = this.leftFighter
        this.log(`🏆 ${this.leftFighter} WINS THE MATCH WITH ${leftScore} POINTS!`)
      } else if (rightScore > leftScore) {
        winner = this.rightFighter
        this.log(`🏆 ${this.rightFighter} WINS THE MATCH WITH ${rightScore} POINTS!`)
      } else {
        winner = null
        this.log(`⚖️ THE MATCH ENDS IN A DRAW WITH ${leftScore} POINTS EACH!`)
      }
    }

    if (knockOut) {
      this.log("💥 KNOCKOUT: Market Melee™ victory!")
    }

    return {
      winner,
      leftScore,
      rightScore,
      logs: this.logs,
      knockOut,
    }
  }

  /**
   * Generates simulated market data for testing
   * @param coin Coin ID
   * @returns Simulated candlestick data
   */
  private generateSimulatedData(coin: string): CandlestickData[] {
    const candles: CandlestickData[] = []
    const now = Date.now()

    // Base price depends on the coin
    const basePrice = coin === "bitcoin" ? 86000 : coin === "ethereum" ? 3500 : coin === "solana" ? 150 : 100

    let lastClose = basePrice

    // Generate data for each round
    for (let i = 0; i <= this.rounds; i++) {
      // Create some realistic price movement
      const volatilityFactor =
        coin === "bitcoin" ? 0.01 : coin === "ethereum" ? 0.015 : coin === "solana" ? 0.03 : 0.025

      const randomChange = (Math.random() - 0.5) * lastClose * volatilityFactor

      // Generate a realistic candle
      const open = lastClose
      const close = open + randomChange
      const high = Math.max(open, close) + Math.random() * Math.abs(randomChange) * 0.5
      const low = Math.min(open, close) - Math.random() * Math.abs(randomChange) * 0.5

      // Generate realistic volume
      const volumeBase =
        coin === "bitcoin" ? 5000000 : coin === "ethereum" ? 3000000 : coin === "solana" ? 2000000 : 1000000
      const volume = volumeBase + Math.random() * volumeBase

      candles.push({
        time: now - i * 60 * 60 * 1000, // hourly candles
        open,
        high,
        low,
        close,
        volume,
      })

      // Set up for next candle
      lastClose = close
    }

    return candles.reverse() // Most recent last
  }

  /**
   * Adds a log message
   * @param message Log message
   */
  private log(message: string): void {
    this.logs.push(message)
    console.log(message)
  }
}

/**
 * Runs a market fight test with the specified options
 * @param options Test options
 * @returns Promise with test results
 */
export async function runMarketFightTest(options: {
  leftFighter: string
  rightFighter: string
  rounds?: number
  useLiveData?: boolean
}): Promise<{
  winner: string | null
  leftScore: number
  rightScore: number
  logs: string[]
  knockOut: boolean
}> {
  const tester = new MarketFightTester(options)
  return tester.runTest()
}

