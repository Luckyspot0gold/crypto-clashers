export interface CandlestickData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface EconomicIndicator {
  name: string
  value: number
  change: number
  isPositive: boolean
  lastUpdated: string
}

export interface IndicatorMovement {
  name: string
  type: "attack" | "defense"
  power: number
  move: string
  description: string
  combo?: number
  duration?: number
}

export interface FighterState {
  health: number
  power: number
  combo: number
  specialCharged: boolean
  lastMove: string
  currentMove: string
  indicators: Record<string, EconomicIndicator>
  movements: IndicatorMovement[]
}

