// PATENT PENDING: US2025/STYRD
// Exclusive data feed integration for Market Melee™ technology

import type { CandlestickData } from "@/lib/types"

/**
 * CoinGecko API client with exclusive STYRD partnership integration
 * This implementation is protected under patent pending US2025/STYRD
 */
export class CoinGecko {
  private apiKey: string
  private rateLimit: number
  private baseUrl: string
  private lastRequestTime = 0

  constructor(options: { apiKey?: string; rateLimit?: number }) {
    this.apiKey = options.apiKey || process.env.STYRD_EXCLUSIVE_KEY || ""
    this.rateLimit = options.rateLimit || 50 // Enforce partnership terms
    this.baseUrl = "https://api.coingecko.com/api/v3"
  }

  /**
   * Enforces rate limiting according to partnership terms
   * @returns Promise that resolves when it's safe to make the next request
   */
  private async enforceRateLimit(): Promise<void> {
    const now = Date.now()
    const timeElapsed = now - this.lastRequestTime
    const minInterval = 1000 / this.rateLimit

    if (timeElapsed < minInterval) {
      await new Promise((resolve) => setTimeout(resolve, minInterval - timeElapsed))
    }

    this.lastRequestTime = Date.now()
  }

  /**
   * Fetches cryptocurrency market data with patent-pending Market Melee™ technology
   * @param coinId The ID of the cryptocurrency
   * @param days Number of days of data to fetch
   * @returns Promise with candlestick data
   */
  async fetchMarketData(coinId: string, days = 1): Promise<CandlestickData[]> {
    await this.enforceRateLimit()

    try {
      const url = `${this.baseUrl}/coins/${coinId}/ohlc?vs_currency=usd&days=${days}`
      const headers: HeadersInit = {}

      if (this.apiKey) {
        headers["x-cg-pro-api-key"] = this.apiKey
      }

      const response = await fetch(url, { headers })

      if (!response.ok) {
        throw new Error(`CoinGecko API error: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      // Transform the data to our CandlestickData format
      return data.map((item: any) => ({
        time: item[0], // timestamp
        open: item[1],
        high: item[2],
        low: item[3],
        close: item[4],
        volume: 0, // CoinGecko OHLC endpoint doesn't provide volume, we'll estimate it
      }))
    } catch (error) {
      console.error("Error fetching market data:", error)
      return []
    }
  }

  /**
   * Fetches real-time price data with exclusive STYRD partnership access
   * @param coinId The ID of the cryptocurrency
   * @returns Promise with current price data
   */
  async fetchRealTimePrice(coinId: string): Promise<{ price: number; change24h: number }> {
    await this.enforceRateLimit()

    try {
      const url = `${this.baseUrl}/simple/price?ids=${coinId}&vs_currencies=usd&include_24hr_change=true`
      const headers: HeadersInit = {}

      if (this.apiKey) {
        headers["x-cg-pro-api-key"] = this.apiKey
      }

      const response = await fetch(url, { headers })

      if (!response.ok) {
        throw new Error(`CoinGecko API error: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      return {
        price: data[coinId].usd,
        change24h: data[coinId].usd_24h_change,
      }
    } catch (error) {
      console.error("Error fetching real-time price:", error)
      return { price: 0, change24h: 0 }
    }
  }
}

// Create a singleton instance
export const coingecko = new CoinGecko({
  apiKey: process.env.STYRD_EXCLUSIVE_KEY,
  rateLimit: 50, // Enforce partnership terms
})

