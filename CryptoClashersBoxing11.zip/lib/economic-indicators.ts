// Economic Indicators API
// This file handles fetching and processing various economic indicators

import type { EconomicIndicator, IndicatorMovement } from "./types"

// Mock data for demonstration - in a real app, you would fetch from actual APIs
const MOCK_INDICATORS = {
  recession: {
    name: "Recession Probability",
    value: 32, // percentage
    change: 2.5,
    isPositive: false,
    lastUpdated: new Date().toISOString(),
  },
  uncertainty: {
    name: "Economic Policy Uncertainty Index",
    value: 245.7,
    change: 15.3,
    isPositive: true,
    lastUpdated: new Date().toISOString(),
  },
  fear: {
    name: "Market Fear Index",
    value: 68.2,
    change: 4.1,
    isPositive: true,
    lastUpdated: new Date().toISOString(),
  },
  kerberos: {
    name: "Kerberos Indicator",
    value: 42.8,
    change: -3.2,
    isPositive: false,
    lastUpdated: new Date().toISOString(),
  },
}

// Fetch economic indicators
export async function fetchEconomicIndicators(): Promise<Record<string, EconomicIndicator>> {
  // In a real app, you would fetch from actual APIs
  // For example:
  // const recessionData = await fetch('https://api.economicdata.org/recession-indicator')
  // const uncertaintyData = await fetch('https://api.economicdata.org/policy-uncertainty')
  // const fearData = await fetch('https://api.economicdata.org/fear-index')

  // For demo purposes, we'll add some randomness to the mock data
  const indicators = { ...MOCK_INDICATORS }

  // Add some random fluctuation to make it look real-time
  Object.keys(indicators).forEach((key) => {
    const indicator = indicators[key as keyof typeof MOCK_INDICATORS]
    const randomChange = (Math.random() - 0.5) * 5
    indicator.value += randomChange
    indicator.change = randomChange
    indicator.isPositive = randomChange > 0
    indicator.lastUpdated = new Date().toISOString()
  })

  return indicators
}

// Map economic indicators to fighter movements
export function mapIndicatorsToMovements(
  indicators: Record<string, EconomicIndicator>,
  fighterType: "bull" | "bear",
): IndicatorMovement[] {
  const movements: IndicatorMovement[] = []

  // Recession indicator affects attack power
  if (indicators.recession) {
    const recessionValue = indicators.recession.value
    const recessionChange = indicators.recession.change

    // TradeWar_Slammer: Recession up = attack, down = defense
    if (recessionChange > 0) {
      movements.push({
        name: "TradeWar_Slammer",
        type: "attack",
        power: Math.min(100, recessionValue / 2),
        move: recessionValue > 50 ? "uppercut" : "hook",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} TradeWar_Slammer activated by rising recession fears!`,
      })
    } else {
      movements.push({
        name: "TradeWar_Slammer",
        type: "defense",
        power: Math.min(100, Math.abs(recessionChange) * 10),
        move: "dodge",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} TradeWar_Slammer defensive stance activated!`,
      })
    }
  }

  // Economic uncertainty affects movement speed
  if (indicators.uncertainty) {
    const uncertaintyValue = indicators.uncertainty.value
    const uncertaintyChange = indicators.uncertainty.change

    // Tax_Axe: Uncertainty up = attack jump, down = defense duck
    if (uncertaintyChange > 0) {
      movements.push({
        name: "Tax_Axe",
        type: "attack",
        power: Math.min(100, uncertaintyValue / 5),
        move: "uppercut",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} Tax_Axe jump attack activated by rising uncertainty!`,
      })
    } else {
      movements.push({
        name: "Tax_Axe",
        type: "defense",
        power: Math.min(100, Math.abs(uncertaintyChange) * 8),
        move: "block",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} Tax_Axe defensive swerve activated!`,
      })
    }
  }

  // Fear index affects special moves
  if (indicators.fear) {
    const fearValue = indicators.fear.value
    const fearChange = indicators.fear.change

    // Birdsarntreal: Fear up = aggressive attack, down = cautious defense
    if (fearChange > 0) {
      movements.push({
        name: "Birdsarntreal",
        type: "attack",
        power: Math.min(100, fearValue),
        move: fearValue > 60 ? "uppercut" : "hook",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} Birdsarntreal combo attack activated by rising fear!`,
        combo: Math.floor(fearValue / 20) + 1,
      })
    } else {
      movements.push({
        name: "Birdsarntreal",
        type: "defense",
        power: Math.min(100, Math.abs(fearChange) * 12),
        move: "dodge",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} Birdsarntreal defensive maneuver activated!`,
      })
    }
  }

  // Kerberos indicator affects special abilities
  if (indicators.kerberos) {
    const kerberosValue = indicators.kerberos.value
    const kerberosChange = indicators.kerberos.change

    // Alien_Invasion: Kerberos up = nitro boost, down = brake check
    if (kerberosChange > 0) {
      movements.push({
        name: "Alien_Invasion",
        type: "attack",
        power: Math.min(100, kerberosValue * 1.5),
        move: "uppercut",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} Alien_Invasion nitro boost activated!`,
        combo: 5,
      })
    } else {
      movements.push({
        name: "Alien_Invasion",
        type: "defense",
        power: Math.min(100, Math.abs(kerberosChange) * 15),
        move: "block",
        description: `${fighterType === "bull" ? "Bullish" : "Bearish"} Alien_Invasion brake check activated!`,
        duration: 3,
      })
    }
  }

  return movements
}

// Get the most powerful movement from the list
export function getMostPowerfulMovement(movements: IndicatorMovement[]): IndicatorMovement | null {
  if (movements.length === 0) return null

  return movements.reduce((prev, current) => (current.power > prev.power ? current : prev))
}

