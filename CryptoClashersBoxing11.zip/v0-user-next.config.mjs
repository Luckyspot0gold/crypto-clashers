/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  env: {
    STYRD_EXCLUSIVE_KEY: process.env.STYRD_EXCLUSIVE_KEY || "",
  },
}

export default nextConfig

