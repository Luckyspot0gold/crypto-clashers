"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, AlertCircle, Database, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { fetchEconomicIndicators } from "@/lib/economic-indicators"
import type { EconomicIndicator } from "@/lib/types"

interface EconomicDashboardProps {
  onIndicatorEffect?: (indicatorName: string, value: number, change: number) => void
}

export default function EconomicDashboard({ onIndicatorEffect }: EconomicDashboardProps) {
  const [indicators, setIndicators] = useState<Record<string, EconomicIndicator>>({})
  const [loading, setLoading] = useState(true)
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null)

  // Fetch economic indicators
  const fetchIndicators = async () => {
    setLoading(true)
    try {
      const data = await fetchEconomicIndicators()
      setIndicators(data)
      setLastUpdated(new Date())

      // Notify parent component of indicator effects
      if (onIndicatorEffect) {
        Object.entries(data).forEach(([name, indicator]) => {
          if (Math.abs(indicator.change) > 1) {
            // Only trigger on significant changes
            onIndicatorEffect(name, indicator.value, indicator.change)
          }
        })
      }
    } catch (error) {
      console.error("Error fetching economic indicators:", error)
    } finally {
      setLoading(false)
    }
  }

  // Fetch indicators on mount and periodically
  useEffect(() => {
    fetchIndicators()

    // Refresh every 30 seconds
    const intervalId = setInterval(fetchIndicators, 30000)

    return () => clearInterval(intervalId)
  }, [onIndicatorEffect])

  // Get indicator trend icon and color
  const getIndicatorTrend = (isPositive: boolean) => {
    return isPositive ? (
      <TrendingUp className="h-4 w-4 text-green-500" />
    ) : (
      <TrendingDown className="h-4 w-4 text-red-500" />
    )
  }

  // Get indicator description
  const getIndicatorDescription = (name: string, value: number, change: number) => {
    switch (name) {
      case "recession":
        return change > 0
          ? "Rising recession probability may trigger TradeWar_Slammer attacks"
          : "Falling recession probability may enhance TradeWar_Slammer defense"
      case "uncertainty":
        return change > 0
          ? "Rising uncertainty may trigger Tax_Axe jump attacks"
          : "Falling uncertainty may enhance Tax_Axe defensive swerves"
      case "fear":
        return change > 0
          ? "Rising fear may trigger Birdsarntreal combo attacks"
          : "Falling fear may enhance Birdsarntreal defensive maneuvers"
      case "kerberos":
        return change > 0
          ? "Rising Kerberos indicator may trigger Alien_Invasion nitro boosts"
          : "Falling Kerberos indicator may trigger Alien_Invasion brake checks"
      default:
        return "This indicator affects fighter performance"
    }
  }

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg flex items-center">
          <Database className="mr-2 h-5 w-5" />
          Economic Indicators
        </CardTitle>
        <Button variant="outline" size="sm" onClick={fetchIndicators} className="h-8 w-8 p-0" disabled={loading}>
          <RefreshCw className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        {loading && Object.keys(indicators).length === 0 ? (
          <div className="flex items-center justify-center h-32">
            <p className="text-gray-400">Loading economic data...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {Object.entries(indicators).map(([key, indicator]) => (
              <div key={key} className="bg-gray-800 rounded-lg p-3">
                <div className="flex justify-between items-center mb-1">
                  <h3 className="font-medium">{indicator.name}</h3>
                  <div className="flex items-center">
                    {getIndicatorTrend(indicator.isPositive)}
                    <span className={`ml-1 ${indicator.isPositive ? "text-green-500" : "text-red-500"}`}>
                      {Math.abs(indicator.change).toFixed(1)}%
                    </span>
                  </div>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-2xl font-bold">{indicator.value.toFixed(1)}</span>
                  <span className="text-xs text-gray-400">
                    Updated: {lastUpdated ? new Date(indicator.lastUpdated).toLocaleTimeString() : "Never"}
                  </span>
                </div>
                <div className="text-xs text-gray-400">
                  <AlertCircle className="inline h-3 w-3 mr-1" />
                  {getIndicatorDescription(key, indicator.value, indicator.change)}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

