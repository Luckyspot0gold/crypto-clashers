"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, Info, AlertTriangle, Lock } from "lucide-react"

export default function PatentInfo() {
  const [showDetails, setShowDetails] = useState(false)

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg flex items-center">
          <Shield className="mr-2 h-5 w-5 text-blue-400" />
          Patent Information
        </CardTitle>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowDetails(!showDetails)}
          className="h-8 bg-gray-800 border-gray-700 hover:bg-gray-700"
        >
          {showDetails ? "Hide Details" : "Show Details"}
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex items-start mb-4">
          <Lock className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium">PATENT PENDING: US2025/STYRD</p>
            <p className="text-sm text-gray-400">Market Melee™ technology for crypto boxing visualization</p>
          </div>
        </div>

        {showDetails && (
          <div className="space-y-4 mt-4">
            <div className="bg-gray-800 rounded-lg p-3">
              <h3 className="font-medium mb-1 flex items-center">
                <Info className="h-4 w-4 text-blue-400 mr-1" />
                Protected Technologies
              </h3>
              <ul className="text-sm text-gray-300 space-y-1 pl-5 list-disc">
                <li>Market Melee™ Formula for translating market data into boxing mechanics</li>
                <li>TradeWar_Slammer recession indicator integration</li>
                <li>Tax_Axe economic policy uncertainty index integration</li>
                <li>Birdsarntreal fear indicator integration</li>
                <li>Alien_Invasion Kerberos indicator integration</li>
                <li>Real-time market-driven animation system</li>
              </ul>
            </div>

            <div className="bg-yellow-900/30 border border-yellow-800 rounded-lg p-3">
              <div className="flex items-start">
                <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-yellow-200">
                  <p className="font-medium mb-1">Legal Notice:</p>
                  <p>
                    This software contains technology protected under patent application US2025/STYRD. Unauthorized use,
                    reproduction, or distribution is strictly prohibited and may result in legal action.
                  </p>
                </div>
              </div>
            </div>

            <div className="text-xs text-gray-500 mt-2">
              © {new Date().getFullYear()} StoneYard.Gaming - All Rights Reserved
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

