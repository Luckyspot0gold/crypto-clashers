"use client"

import { useEffect, useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { TrendingUp, TrendingDown, Database } from "lucide-react"
import type { CandlestickData, EconomicIndicator, FighterState } from "@/lib/types"
import { fetchEconomicIndicators, mapIndicatorsToMovements, getMostPowerfulMovement } from "@/lib/economic-indicators"

interface EnhancedBoxingRingProps {
  leftFighter: {
    id: string
    name: string
    symbol: string
    icon: string
    color: string
    type: "bull" | "bear"
  }
  rightFighter: {
    id: string
    name: string
    symbol: string
    icon: string
    color: string
    type: "bull" | "bear"
  }
  leftAction: string
  rightAction: string
  leftPerformance: any | null
  rightPerformance: any | null
  gameSpeed: number
  leftData: CandlestickData[]
  rightData: CandlestickData[]
  userControls: {
    leftPower: number
    rightPower: number
    leftCombo?: number
    rightCombo?: number
    leftLastMove?: string
    rightLastMove?: string
    leftSpecialCharged?: boolean
    rightSpecialCharged?: boolean
  }
  onUserAction: (action: string, fighter: "left" | "right") => void
  onLogMessage: (message: string) => void
  cameraAngle?: "side" | "forward"
  betOn?: string | null
}

export default function EnhancedBoxingRing({
  leftFighter,
  rightFighter,
  leftAction,
  rightAction,
  leftPerformance,
  rightPerformance,
  gameSpeed,
  leftData,
  rightData,
  userControls,
  onUserAction,
  onLogMessage,
  cameraAngle = "side",
  betOn = null,
}: EnhancedBoxingRingProps) {
  const [leftHealth, setLeftHealth] = useState(100)
  const [rightHealth, setRightHealth] = useState(100)
  const [winner, setWinner] = useState<string | null>(null)
  const [roundTime, setRoundTime] = useState(60) // 60 second rounds
  const animationRef = useRef<number | null>(null)
  const lastUpdateTime = useRef<number>(Date.now())
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [leftAnimationState, setLeftAnimationState] = useState("idle")
  const [rightAnimationState, setRightAnimationState] = useState("idle")
  const [isMatchActive, setIsMatchActive] = useState(true) // Track if the match is active

  // Economic indicators state
  const [economicIndicators, setEconomicIndicators] = useState<Record<string, EconomicIndicator>>({})
  const [leftFighterState, setLeftFighterState] = useState<FighterState>({
    health: 100,
    power: 0,
    combo: 0,
    specialCharged: false,
    lastMove: "",
    currentMove: "idle",
    indicators: {},
    movements: [],
  })
  const [rightFighterState, setRightFighterState] = useState<FighterState>({
    health: 100,
    power: 0,
    combo: 0,
    specialCharged: false,
    lastMove: "",
    currentMove: "idle",
    indicators: {},
    movements: [],
  })
  const [showIndicatorEffect, setShowIndicatorEffect] = useState<{
    name: string
    description: string
    isLeft: boolean
  } | null>(null)

  // Fetch economic indicators periodically
  useEffect(() => {
    const fetchIndicators = async () => {
      try {
        const indicators = await fetchEconomicIndicators()
        setEconomicIndicators(indicators)

        // Map indicators to movements for each fighter
        const leftMovements = mapIndicatorsToMovements(indicators, leftFighter.type)
        const rightMovements = mapIndicatorsToMovements(indicators, rightFighter.type)

        // Update fighter states with new indicators and movements
        setLeftFighterState((prev) => ({
          ...prev,
          indicators,
          movements: leftMovements,
        }))

        setRightFighterState((prev) => ({
          ...prev,
          indicators,
          movements: rightMovements,
        }))

        // Get the most powerful movement for each fighter
        const leftPowerMove = getMostPowerfulMovement(leftMovements)
        const rightPowerMove = getMostPowerfulMovement(rightMovements)

        // Log the economic indicator effects
        if (leftPowerMove) {
          onLogMessage(`<span class="text-${leftFighter.color}-400">${leftPowerMove.description}</span>`)
          setShowIndicatorEffect({
            name: leftPowerMove.name,
            description: leftPowerMove.description,
            isLeft: true,
          })

          // Clear the effect after 3 seconds
          setTimeout(() => setShowIndicatorEffect(null), 3000)
        }

        if (rightPowerMove) {
          onLogMessage(`<span class="text-${rightFighter.color}-400">${rightPowerMove.description}</span>`)
          if (!leftPowerMove) {
            setShowIndicatorEffect({
              name: rightPowerMove.name,
              description: rightPowerMove.description,
              isLeft: false,
            })

            // Clear the effect after 3 seconds
            setTimeout(() => setShowIndicatorEffect(null), 3000)
          }
        }
      } catch (error) {
        console.error("Error fetching economic indicators:", error)
      }
    }

    // Fetch indicators immediately
    fetchIndicators()

    // Then fetch every 10 seconds
    const intervalId = setInterval(fetchIndicators, 10000)

    return () => clearInterval(intervalId)
  }, [leftFighter.type, rightFighter.type, leftFighter.color, rightFighter.color, onLogMessage])

  // Apply economic indicator effects to fighter actions
  useEffect(() => {
    if (!isMatchActive) return

    // Get the most powerful movement for each fighter
    const leftPowerMove = getMostPowerfulMovement(leftFighterState.movements)
    const rightPowerMove = getMostPowerfulMovement(rightFighterState.movements)

    // Apply the movement effects
    if (leftPowerMove && Math.random() < 0.3) {
      // 30% chance to trigger
      setLeftAnimationState(leftPowerMove.move)

      // Apply damage if it's an attack
      if (leftPowerMove.type === "attack") {
        const damage = leftPowerMove.power / 10 // Scale down the damage
        setRightHealth((prev) => Math.max(0, prev - damage))

        // Apply combo if specified
        if (leftPowerMove.combo && leftPowerMove.combo > 1) {
          onLogMessage(
            `<span class="text-yellow-400">🔥 ${leftPowerMove.combo}x COMBO! ${leftFighter.name}'s ${leftPowerMove.name} activated!</span>`,
          )
        }
      }
    }

    if (rightPowerMove && Math.random() < 0.3) {
      // 30% chance to trigger
      setRightAnimationState(rightPowerMove.move)

      // Apply damage if it's an attack
      if (rightPowerMove.type === "attack") {
        const damage = rightPowerMove.power / 10 // Scale down the damage
        setLeftHealth((prev) => Math.max(0, prev - damage))

        // Apply combo if specified
        if (rightPowerMove.combo && rightPowerMove.combo > 1) {
          onLogMessage(
            `<span class="text-yellow-400">🔥 ${rightPowerMove.combo}x COMBO! ${rightFighter.name}'s ${rightPowerMove.name} activated!</span>`,
          )
        }
      }
    }
  }, [
    economicIndicators,
    isMatchActive,
    leftFighterState.movements,
    rightFighterState.movements,
    leftFighter.name,
    rightFighter.name,
    onLogMessage,
  ])

  // Rest of the component remains the same as BoxingRing...
  // (Include all the existing BoxingRing functionality here)

  // Add economic indicator display
  const renderEconomicIndicators = () => {
    return (
      <div className="absolute top-4 right-4 bg-gray-900 bg-opacity-80 rounded-lg p-2 max-w-xs">
        <h3 className="text-sm font-bold mb-1 flex items-center">
          <Database className="h-3 w-3 mr-1" />
          Economic Indicators
        </h3>
        <div className="space-y-1 text-xs">
          {Object.entries(economicIndicators).map(([key, indicator]) => (
            <div key={key} className="flex justify-between">
              <span>{indicator.name}:</span>
              <span className={indicator.isPositive ? "text-green-400" : "text-red-400"}>
                {indicator.value.toFixed(1)}
                {indicator.isPositive ? (
                  <TrendingUp className="inline h-3 w-3 ml-1" />
                ) : (
                  <TrendingDown className="inline h-3 w-3 ml-1" />
                )}
              </span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // Render indicator effect overlay
  const renderIndicatorEffect = () => {
    if (!showIndicatorEffect) return null

    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className={`absolute ${showIndicatorEffect.isLeft ? "left-1/4" : "right-1/4"} top-1/4 transform -translate-x-1/2 -translate-y-1/2 bg-gray-900 bg-opacity-80 rounded-lg p-2 border-2 z-10`}
          style={{
            borderColor: showIndicatorEffect.isLeft
              ? getColorFromName(leftFighter.color)
              : getColorFromName(rightFighter.color),
          }}
        >
          <h3 className="text-lg font-bold mb-1">{showIndicatorEffect.name}</h3>
          <p className="text-sm">{showIndicatorEffect.description}</p>
        </motion.div>
      </AnimatePresence>
    )
  }

  // Add this to your return statement
  return (
    <div className="relative rounded-xl overflow-hidden h-[500px]">
      {/* Existing BoxingRing content */}

      {/* Add economic indicators display */}
      {renderEconomicIndicators()}

      {/* Add indicator effect overlay */}
      {renderIndicatorEffect()}
    </div>
  )
}

// Helper function to get color from name
function getColorFromName(colorName: string): string {
  const colorMap: Record<string, string> = {
    orange: "#F97316",
    purple: "#8B5CF6",
    blue: "#3B82F6",
    red: "#EF4444",
    green: "#10B981",
    yellow: "#FACC15",
    gray: "#6B7280",
    pink: "#EC4899",
    black: "#1F2937",
  }

  return colorMap[colorName] || "#6B7280"
}

