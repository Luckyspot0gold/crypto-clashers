"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { PlayCircle, Database, Trophy, AlertTriangle } from "lucide-react"
import { runMarketFightTest } from "@/lib/testing/market-fights"
import { kerberosAuth } from "@/lib/auth/kerberos"

export default function MarketTestRunner() {
  const [leftFighter, setLeftFighter] = useState("bitcoin")
  const [rightFighter, setRightFighter] = useState("solana")
  const [rounds, setRounds] = useState(8)
  const [useLiveData, setUseLiveData] = useState(false)
  const [isRunning, setIsRunning] = useState(false)
  const [testResults, setTestResults] = useState<{
    winner: string | null
    leftScore: number
    rightScore: number
    logs: string[]
    knockOut: boolean
  } | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authStatus, setAuthStatus] = useState("")

  // Authenticate with Kerberos
  const authenticate = async () => {
    const success = await kerberosAuth.authenticate()
    setIsAuthenticated(success)
    setAuthStatus(
      success
        ? `Authenticated as styrd-admin@WYOVERSE.ORG (${kerberosAuth.formatRemainingTime()})`
        : "Authentication failed",
    )
  }

  // Run the market test
  const runTest = async () => {
    if (useLiveData && !isAuthenticated) {
      setAuthStatus("Authentication required for live data")
      return
    }

    setIsRunning(true)
    setTestResults(null)

    try {
      const results = await runMarketFightTest({
        leftFighter,
        rightFighter,
        rounds,
        useLiveData,
      })

      setTestResults(results)
    } catch (error) {
      console.error("Error running market test:", error)
    } finally {
      setIsRunning(false)
    }
  }

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center">
          <PlayCircle className="mr-2 h-5 w-5 text-green-400" />
          Market-Driven Match Test
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Left Fighter</label>
              <Input
                value={leftFighter}
                onChange={(e) => setLeftFighter(e.target.value)}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Right Fighter</label>
              <Input
                value={rightFighter}
                onChange={(e) => setRightFighter(e.target.value)}
                className="bg-gray-800 border-gray-700"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Rounds</label>
              <Input
                type="number"
                min={1}
                max={12}
                value={rounds}
                onChange={(e) => setRounds(Number.parseInt(e.target.value) || 8)}
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div className="flex items-end">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="live-data"
                  checked={useLiveData}
                  onCheckedChange={(checked) => setUseLiveData(checked === true)}
                />
                <label
                  htmlFor="live-data"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Use Live Data
                </label>
              </div>
            </div>
          </div>

          {useLiveData && !isAuthenticated && (
            <div className="bg-blue-900/30 border border-blue-800 rounded-lg p-3">
              <div className="flex items-start">
                <Database className="h-4 w-4 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                <div className="text-sm">
                  <p className="font-medium mb-1">Authentication Required</p>
                  <p className="text-gray-300 mb-2">Kerberos authentication is required to access live market data.</p>
                  <Button size="sm" onClick={authenticate} className="bg-blue-600 hover:bg-blue-700">
                    Authenticate with Kerberos
                  </Button>
                </div>
              </div>
            </div>
          )}

          {authStatus && <div className="text-sm text-gray-400">{authStatus}</div>}

          <Button
            onClick={runTest}
            disabled={isRunning}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
          >
            {isRunning ? "Running Test..." : "Run Market Test"}
          </Button>

          {testResults && (
            <div className="mt-4 space-y-4">
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="font-bold mb-2 flex items-center">
                  <Trophy className="h-5 w-5 mr-2 text-yellow-400" />
                  Test Results
                </h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Winner:</span>
                    <span className="font-bold">
                      {testResults.winner || "Draw"}
                      {testResults.knockOut && " (Knockout)"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Final Score:</span>
                    <span className="font-bold">
                      {leftFighter} {testResults.leftScore} - {testResults.rightScore} {rightFighter}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-800 rounded-lg p-4 max-h-60 overflow-y-auto">
                <h3 className="font-bold mb-2">Battle Log</h3>
                <div className="space-y-1 text-sm">
                  {testResults.logs.map((log, index) => (
                    <div key={index} className="text-gray-300">
                      {log}
                    </div>
                  ))}
                </div>
              </div>

              {testResults.knockOut && (
                <div className="bg-green-900/30 border border-green-800 rounded-lg p-3">
                  <div className="flex items-start">
                    <AlertTriangle className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                    <div className="text-sm text-green-200">
                      <p className="font-bold">💥 KNOCKOUT: Market Melee™ victory!</p>
                      <p>The match ended with a decisive knockout victory!</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

